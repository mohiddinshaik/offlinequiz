import { Component } from '@angular/core';
import { DataSource } from '@angular/cdk/table';
import { SelectionModel } from '@angular/cdk/collections';


const USER_INFO = [
  { id:1,"name": "John Smith", "location": "us", "phone": 36, "showadd": false,checked:false },
  { id:2,"name": "Muhi Masri", "location": "uk", "phone": 28, "showadd": false,checked:false },
  {id:3, "name": "Peter Adams", "location": "in", "phone": 20, "showadd": false,checked:false },
  { id:4,"name": "Lora Bay", "location": "ja", "phone": 43, "showadd": false,checked:false }
];
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  displayedColumns: string[] = ['select', 'id', 'name', 'location', 'phone'];
  dataSource = USER_INFO;
  edited:String ="Edit";
  save:String ="Add";
 

  selection = new SelectionModel(true, []);
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.length;

    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.forEach(row => this.selection.select(row));
  }

  add() {
    if(this.save=="Add"){
      this.save="save";
      this.dataSource.push({ id:this.dataSource.length+1,"name": "", "location": "", "phone": null, 'showadd': true,checked:true });
      this.dataSource = this.dataSource.slice();
      this.selection.select({ id:this.dataSource.length+1,"name": "", "location": "", "phone": null, 'showadd': true,checked:true })
    }else {
      this.save="Add";
      this.dataSource.forEach(row => {row.checked=false;row.showadd=false});
      this.selection.clear()
    }
    console.log(this.dataSource.length);


  }
  edit() {
    if(this.edited=='Edit'){
      this.edited = "update";
      this.selection.selected.forEach(function(data) {
        data.showadd = true;
        data.checked=true;
      });

    }else{
      this.edited = "Edit";
      this.selection.selected.forEach(function(data) {
        data.showadd = false;
        data.checked=false;
       
      });
      this.selection.clear()

    }
    console.log(this.selection.selected);

  }
  a=this.dataSource.slice();
 
  delete() {
for(let i=0;i<this.selection.selected.length;i++){
  console.log(this.selection.selected[i])
  var ss=this.selection.selected[i]
 this.a= this.a.filter(function(d){
return d.id!=ss.id;
  })

}
// this.selection.selected.map(function(data){
// this.a.splice(data.id,1);
 
// })
console.log(this.a)
this.dataSource=this.a.slice();

  }
}
